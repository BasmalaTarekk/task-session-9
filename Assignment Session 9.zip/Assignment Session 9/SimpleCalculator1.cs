using System;

class Program
{
    static void Main()
    {
        Console.Write("Input the first number: ");
        double num1 = double.Parse(Console.ReadLine());

        Console.Write("Input the second number: ");
        double num2 = double.Parse(Console.ReadLine());

        Console.WriteLine("Choose the operation to apply to these numbers:");
        Console.WriteLine
        ("[A]dd\n
        [S]ubtract\n
        [M]ultiply");

        string choice = Console.ReadLine().ToUpper();
        switch (choice)
        {
            case "A":
                Console.WriteLine($"{num1} + {num2} = {num1 + num2}");
                break;
            case "S":
                Console.WriteLine($"{num1} - {num2} = {num1 - num2}");
                break;
            case "M":
                Console.WriteLine($"{num1} * {num2} = {num1 * num2}");
                break;
            default:
                Console.WriteLine("Invalid option");
                break;
        }

        Console.WriteLine("Press any key to close");
        Console.ReadKey();
    }
}